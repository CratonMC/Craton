package com.teamtea.craton.common.worldgen.noise;

/**
 * Deterministic gradient noise utilities for single-point geology sampling.
 * No neighborhood state is required, so the same xyz always reconstructs the same field.
 */
public class GeologicalNoise {
    private GeologicalNoise(){}

    /** Stable 64-bit mixing shared by geology and deposit fields. */
    public static long mix(long z){
        z=(z^(z>>>30))*0xbf58476d1ce4e5b9L;
        z=(z^(z>>>27))*0x94d049bb133111ebL;
        return z^(z>>>31);
    }

    public static double perlin(double x,double y,double z,long seed){
        int x0=floor(x),y0=floor(y),z0=floor(z);
        double xf=x-x0,yf=y-y0,zf=z-z0;
        double u=fade(xf),v=fade(yf),w=fade(zf);

        long hx0=mixCoord(x0,0x632BE59BD9B4E019L),hx1=mixCoord(x0+1,0x632BE59BD9B4E019L);
        long hy0=mixCoord(y0,0x9E3779B97F4A7C15L),hy1=mixCoord(y0+1,0x9E3779B97F4A7C15L);
        long hz0=mixCoord(z0,0xC6BC279692B5C323L),hz1=mixCoord(z0+1,0xC6BC279692B5C323L);

        double n000=grad(mix(seed^hx0^hy0^hz0),xf,yf,zf);
        double n100=grad(mix(seed^hx1^hy0^hz0),xf-1,yf,zf);
        double n010=grad(mix(seed^hx0^hy1^hz0),xf,yf-1,zf);
        double n110=grad(mix(seed^hx1^hy1^hz0),xf-1,yf-1,zf);
        double n001=grad(mix(seed^hx0^hy0^hz1),xf,yf,zf-1);
        double n101=grad(mix(seed^hx1^hy0^hz1),xf-1,yf,zf-1);
        double n011=grad(mix(seed^hx0^hy1^hz1),xf,yf-1,zf-1);
        double n111=grad(mix(seed^hx1^hy1^hz1),xf-1,yf-1,zf-1);

        double nx00=lerp(u,n000,n100),nx10=lerp(u,n010,n110);
        double nx01=lerp(u,n001,n101),nx11=lerp(u,n011,n111);
        return clamp(lerp(w,lerp(v,nx00,nx10),lerp(v,nx01,nx11))*0.93,-1,1);
    }

    private static double perlin2(double x,double z,long seed){
        int x0=floor(x),z0=floor(z);
        double xf=x-x0,zf=z-z0;
        double u=fade(xf),w=fade(zf);
        long hx0=mixCoord(x0,0x632BE59BD9B4E019L),hx1=mixCoord(x0+1,0x632BE59BD9B4E019L);
        long hy=mixCoord(0,0x9E3779B97F4A7C15L);
        long hz0=mixCoord(z0,0xC6BC279692B5C323L),hz1=mixCoord(z0+1,0xC6BC279692B5C323L);
        double n00=grad(mix(seed^hx0^hy^hz0),xf,0,zf);
        double n10=grad(mix(seed^hx1^hy^hz0),xf-1,0,zf);
        double n01=grad(mix(seed^hx0^hy^hz1),xf,0,zf-1);
        double n11=grad(mix(seed^hx1^hy^hz1),xf-1,0,zf-1);
        return clamp(lerp(w,lerp(u,n00,n10),lerp(u,n01,n11))*0.93,-1,1);
    }

    public static double fbm(double x,double y,double z,long seed,double frequency,int octaves){
        double sum=0,amp=1,norm=0,f=frequency;
        for(int i=0;i<octaves;i++){
            sum+=perlin(x*f,y*f,z*f,mix(seed+i*0x9E3779B97F4A7C15L))*amp;
            norm+=amp;
            amp*=0.5;
            f*=2.03;
        }
        return norm==0?0:sum/norm;
    }

    public static double fbm2(double x,double z,long seed,double frequency,int octaves){
        double sum=0,amp=1,norm=0,f=frequency;
        for(int i=0;i<octaves;i++){
            sum+=perlin2(x*f,z*f,mix(seed+i*0x9E3779B97F4A7C15L))*amp;
            norm+=amp;
            amp*=0.5;
            f*=2.03;
        }
        return norm==0?0:sum/norm;
    }

    /** Correlated field in [0,1], useful as stable block occupancy rather than white-noise hash. */
    public static double occupancy(double x,double y,double z,long seed,double frequency){
        double broad=fbm(x,y,z,seed,frequency,3);
        double detail=perlin(x*frequency*3.7,y*frequency*3.7,z*frequency*3.7,seed^0xD1B54A32D192ED03L);
        double micro=hashUnit(floor(x),floor(y),floor(z),seed^0x94D049BB133111EBL)*2-1;
        return clamp(0.5+0.5*(broad*0.72+detail*0.20+micro*0.08),0,1);
    }

    /** Exact lattice-gradient cache. Mutable samplers belong to one generation context. */
    private static class Lattice {
        private final long seed;
        private int cellX,cellY,cellZ;
        private boolean initialized;
        private int h000,h100,h010,h110,h001,h101,h011,h111;
        private long hx0,hx1,hy0,hy1,hz0,hz1;

        private Lattice(long seed){this.seed=seed;}

        private double sample(double x,double y,double z){
            int x0=floor(x),y0=floor(y),z0=floor(z);
            if(!initialized||x0!=cellX||y0!=cellY||z0!=cellZ){
                // Column traversal changes Y most often; retain unchanged axis hashes.
                if(!initialized||x0!=cellX){
                    hx0=mixCoord(x0,0x632BE59BD9B4E019L);hx1=mixCoord(x0+1,0x632BE59BD9B4E019L);
                }
                if(!initialized||y0!=cellY){
                    hy0=mixCoord(y0,0x9E3779B97F4A7C15L);hy1=mixCoord(y0+1,0x9E3779B97F4A7C15L);
                }
                if(!initialized||z0!=cellZ){
                    hz0=mixCoord(z0,0xC6BC279692B5C323L);hz1=mixCoord(z0+1,0xC6BC279692B5C323L);
                }
                h000=(int)(mix(seed^hx0^hy0^hz0)&15);
                h100=(int)(mix(seed^hx1^hy0^hz0)&15);
                h010=(int)(mix(seed^hx0^hy1^hz0)&15);
                h110=(int)(mix(seed^hx1^hy1^hz0)&15);
                h001=(int)(mix(seed^hx0^hy0^hz1)&15);
                h101=(int)(mix(seed^hx1^hy0^hz1)&15);
                h011=(int)(mix(seed^hx0^hy1^hz1)&15);
                h111=(int)(mix(seed^hx1^hy1^hz1)&15);
                cellX=x0;cellY=y0;cellZ=z0;initialized=true;
            }
            double xf=x-x0,yf=y-y0,zf=z-z0;
            double u=fade(xf),v=fade(yf),w=fade(zf);
            double n000=grad(h000,xf,yf,zf),n100=grad(h100,xf-1,yf,zf);
            double n010=grad(h010,xf,yf-1,zf),n110=grad(h110,xf-1,yf-1,zf);
            double n001=grad(h001,xf,yf,zf-1),n101=grad(h101,xf-1,yf,zf-1);
            double n011=grad(h011,xf,yf-1,zf-1),n111=grad(h111,xf-1,yf-1,zf-1);
            double nx00=lerp(u,n000,n100),nx10=lerp(u,n010,n110);
            double nx01=lerp(u,n001,n101),nx11=lerp(u,n011,n111);
            return clamp(lerp(w,lerp(v,nx00,nx10),lerp(v,nx01,nx11))*0.93,-1,1);
        }
    }

    /** Preserves the original octave seeds, arithmetic order and normalization. */
    public static class CachedFbm {
        private final Lattice[] octaves;
        private final double[] frequencies;
        private final double normalization;

        public CachedFbm(long seed,double frequency,int count){
            octaves=new Lattice[count];
            frequencies=new double[count];
            double f=frequency,amp=1,norm=0;
            for(int i=0;i<count;i++){
                octaves[i]=new Lattice(mix(seed+i*0x9E3779B97F4A7C15L));
                frequencies[i]=f;
                norm+=amp;
                amp*=0.5;
                f*=2.03;
            }
            normalization=norm;
        }

        public double sample(double x,double y,double z){
            double sum=0,amp=1;
            for(int i=0;i<octaves.length;i++){
                double f=frequencies[i];
                sum+=octaves[i].sample(x*f,y*f,z*f)*amp;
                amp*=0.5;
            }
            return normalization==0?0:sum/normalization;
        }
    }

    public static class CachedOccupancy {
        private final CachedFbm broad;
        private final Lattice detail;
        private final long microSeed;
        private final double frequency;
        private boolean initialized;
        private int lastX,lastZ;
        private long hx,hz;

        public CachedOccupancy(long seed,double frequency){
            this.frequency=frequency;
            broad=new CachedFbm(seed,frequency,3);
            detail=new Lattice(seed^0xD1B54A32D192ED03L);
            microSeed=seed^0x94D049BB133111EBL;
        }

        public double sample(double x,double y,double z){
            double b=broad.sample(x,y,z);
            // Keep multiplication order identical to occupancy(), including 3.7.
            double d=detail.sample(x*frequency*3.7,y*frequency*3.7,z*frequency*3.7);
            int ix=floor(x),iz=floor(z);
            if(!initialized||ix!=lastX||iz!=lastZ){
                hx=mixCoord(ix,0x9E3779B185EBCA87L);
                hz=mixCoord(iz,0x165667B19E3779F9L);
                lastX=ix;lastZ=iz;initialized=true;
            }
            long h=mix(microSeed^hx^mixCoord(floor(y),0xC2B2AE3D27D4EB4FL)^hz);
            double micro=(((h>>>11)&((1L<<53)-1))*0x1.0p-53)*2-1;
            return clamp(0.5+0.5*(b*0.72+d*0.20+micro*0.08),0,1);
        }
    }

    public static double smoothstep(double edge0,double edge1,double x){
        if(edge0==edge1) return x<edge0?0:1;
        double t=clamp((x-edge0)/(edge1-edge0),0,1);
        return t*t*(3-2*t);
    }

    public static double hashUnit(int x,int y,int z,long seed){
        long h=seed;
        h^=mixCoord(x,0x9E3779B185EBCA87L);
        h^=mixCoord(y,0xC2B2AE3D27D4EB4FL);
        h^=mixCoord(z,0x165667B19E3779F9L);
        h=mix(h);
        return ((h>>>11)&((1L<<53)-1))*0x1.0p-53;
    }

    private static long mixCoord(long v,long mul){return mix(v*mul);}

    private static double grad(long hash,double x,double y,double z){
        int h=(int)(hash&15);
        double u=h<8?x:y;
        double v=h<4?y:(h==12||h==14?x:z);
        return ((h&1)==0?u:-u)+((h&2)==0?v:-v);
    }

    private static double fade(double t){return t*t*t*(t*(t*6-15)+10);}
    private static double lerp(double t,double a,double b){return a+t*(b-a);}
    private static int floor(double v){int i=(int)v;return v<i?i-1:i;}
    public static double clamp(double v,double min,double max){return Math.max(min,Math.min(max,v));}
}
